day = "17"
year = "1983"
month = "February"

my_birthday = month + " " + day + ", " + year

print (my_birthday)

first = "happy"
second = "birthday"
third = "to"
fourth = "you"

final = first+" " + second + " "+ third+" " + fourth
print (final)

age = 15

if age >=18 : 
   print ("Permitted to attend alone") 

elif age<10 :
    print("Not permitted")

elif age<15 :
    print("Permitted with a parent")

elif age<18 :
    print("Permitted with anyone over 18")
    


